using System.Diagnostics;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Windows.Forms;
using Timer = System.Windows.Forms.Timer;

namespace MiniTaskManager;
public partial class Form1 : Form
{
    private System.Windows.Forms.Timer refillTimer;
    public Form1()
    {
        InitializeComponent();
        fillListView();
        refillTimer = new Timer();
        refillTimer.Interval = 8000;//her 8 saniyede bir isleyir azalda bilersiniz amma ondada hansisa programi kill etmek cetin olacaq cunki refresh olduqda istediyiniz programin id-si ddeyise biler.
        refillTimer.Tick += (i, e) => { fillListView(); };
    }
    private void fillListView()
    {
        MiniTaskManager.Items.Clear();
        var processes = Process.GetProcesses();
        var blacklist = processes.Where(x => x.ProcessName == "mspaint" || x.ProcessName == "ms-teams");
        foreach (var item in blacklist)
        {
            item.Kill();
        }
        MiniTaskManager.Items.Add("ID\tMachine Name\tProcess Name");
        int count = 0;
        foreach (Process process in processes)
        {
            MiniTaskManager.Items.Add(process.Id.ToString() + "\t  " + process.MachineName + "\t\t" + process.ProcessName);
            count++;
        }
        label1.Text = count.ToString();
    }
    private void Create_btn_Click(object sender, EventArgs e)
    {
        try
        {
            Process.Start(textBox1.Text);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message);
        }
    }
    private void End_btn_Click(object sender, EventArgs e)
    {
        //asagidaki algorithm-de men Process-i index-e gore Kill etmek ucun listbox-da secilmish item-in saxladigi indexe catmisam
        int spaceIndex = MiniTaskManager.SelectedItem.ToString().IndexOf(' ');//ilk boslug qeder olaan hisse id-dir

        int id = int.Parse(MiniTaskManager.SelectedItem.ToString().Substring(0, spaceIndex));//0 dan bosluga qeder olan hisseni yeni id-ni goturub int-e cevirdim
        Process.GetProcessById(id).Kill();
        fillListView();
    }

    private void Form1_Load(object sender, EventArgs e)
    {
        refillTimer.Start();
    }

    private void button1_Click(object sender, EventArgs e)
    {
        var form= new Form2();
        form.ShowDialog();
    }

}
