﻿namespace MiniTaskManager
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            End_btn = new Button();
            Create_btn = new Button();
            textBox1 = new TextBox();
            MiniTaskManager = new ListBox();
            label1 = new Label();
            button1 = new Button();
            SuspendLayout();
            // 
            // End_btn
            // 
            End_btn.BackColor = SystemColors.ActiveCaption;
            End_btn.FlatStyle = FlatStyle.Popup;
            End_btn.Location = new Point(666, 396);
            End_btn.Name = "End_btn";
            End_btn.Size = new Size(125, 42);
            End_btn.TabIndex = 1;
            End_btn.Text = "End Task";
            End_btn.UseVisualStyleBackColor = false;
            End_btn.Click += End_btn_Click;
            // 
            // Create_btn
            // 
            Create_btn.Location = new Point(522, 396);
            Create_btn.Name = "Create_btn";
            Create_btn.Size = new Size(125, 42);
            Create_btn.TabIndex = 2;
            Create_btn.Text = "Create Task";
            Create_btn.UseVisualStyleBackColor = true;
            Create_btn.Click += Create_btn_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(123, 407);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(393, 27);
            textBox1.TabIndex = 3;
            // 
            // MiniTaskManager
            // 
            MiniTaskManager.FormattingEnabled = true;
            MiniTaskManager.ItemHeight = 20;
            MiniTaskManager.Location = new Point(0, 7);
            MiniTaskManager.Name = "MiniTaskManager";
            MiniTaskManager.Size = new Size(800, 364);
            MiniTaskManager.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(22, 407);
            label1.Name = "label1";
            label1.Size = new Size(0, 20);
            label1.TabIndex = 5;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ActiveCaptionText;
            button1.FlatStyle = FlatStyle.Popup;
            button1.ForeColor = SystemColors.ButtonHighlight;
            button1.Location = new Point(813, 7);
            button1.Name = "button1";
            button1.Size = new Size(46, 42);
            button1.TabIndex = 6;
            button1.Text = "\\/";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(871, 449);
            Controls.Add(button1);
            Controls.Add(label1);
            Controls.Add(MiniTaskManager);
            Controls.Add(textBox1);
            Controls.Add(Create_btn);
            Controls.Add(End_btn);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button End_btn;
        private Button Create_btn;
        private TextBox textBox1;
        private ListBox MiniTaskManager;
        private Label label1;
        private Button button1;
    }
}
